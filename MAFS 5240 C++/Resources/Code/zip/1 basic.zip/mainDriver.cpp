#include "sizeofBasicTypes.h"
#include "unsignedDemo.h"
#include <iostream>
using namespace std;

int main() {
	sizeofBasicTypes();
	unsignedDemo();
}