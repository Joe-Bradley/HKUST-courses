#pragma once

int __declspec(dllexport) Max(int a[], int n);

double __declspec(dllexport) Avg(int a[], int n);