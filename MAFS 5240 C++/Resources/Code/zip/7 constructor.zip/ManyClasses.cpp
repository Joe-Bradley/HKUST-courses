#include "ManyClasses.h"

noDefConstructor::noDefConstructor(int i) {
	this->i = i;
}