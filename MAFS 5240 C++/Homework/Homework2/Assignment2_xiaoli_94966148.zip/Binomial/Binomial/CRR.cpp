﻿#include "CRR.h"
#include <iostream>
#include <math.h>

using namespace std;

int CRRBinomialTree(
	CALL_PUT	callOrPut,				/* (I) put or call flag (use Call or Put) */
	AMER_EURO	amerOrEuro,				/* (I) option type (use European, American) */
	double		spotPrice,				/* (I) spot price of underlying */
	double		strike,					/* (I) strike price of option */
	double		maturity,				/* (I) maturity of option in years */
	double		vol,					/* (I) annual volatility of underlying */
	double		rate,					/* (I) annual continuous compounded discount rate */
	int			nStep,					/* (I) number of steps in tree */
	double		*value)					/* (O) option value */
/*-----------------------------------------------------------------------------
** FUNCTION:	CRRBinomialTree.
**
** DESCRIPTION:	Calculates the price of an option using the Cox, Ross and Rubinstein
**				binomial tree model.
**
** RETURNS:		SUCCESS and the premium, otherwise FAILURE.                                  
**
**---------------------------------------------------------------------------*/
{

	if (nStep <= 0)
	{
		cout << "CRRBinomialTree: Negative number of steps." << endl;
		return FAILURE;
	}            
	
	if (spotPrice <= 0.0 || strike <= 0.0 || maturity < 0.0 || vol < 0.0 || rate < 0.0)
	{
		cout << "CRRBinomialTree: Invalid input detected." << endl;
		return FAILURE;
	}

	// TO-BE-COMPLETED
    const double up = exp(vol * sqrt(maturity / nStep));
    const double down = exp(-1 * vol * sqrt(maturity / nStep));
    const double prob = (exp(rate * maturity / nStep) - down) / (up - down);
    const double disc = exp(-rate * maturity / nStep);
    
    // initial values at time T
    double* p = new double[nStep + 1];
    double* q = new double[nStep + 1];

    for (int i = 0; i <= nStep; ++i) {
        //计算节点价值
        p[i] = MAX((spotPrice * pow(up, 2 * i - nStep) - strike) * OPTION_MULTIPLIER(callOrPut), 0);
        cout << p[i] << endl;
    }

    // move to earlier times
    for (int j = nStep - 1; j >= 0; --j) {
        for (int i = 0; i <= j; ++i) {
            // values at time j
            q = p;
            p[i] = (1 - prob) * q[i] + prob * q[i + 1];
            p[i] = p[i] * disc;

            // American put option for special process
            if (amerOrEuro == American && callOrPut == Put && p[i] < strike - spotPrice * pow(up, 2 * i - j)) {
                p[i] = strike - spotPrice * pow(up, 2 * i - j);
            }
        }
        cout << endl;
    }

    *value = p[0];
    delete[] p, q;

	return SUCCESS;
}