#include "CurveData.h"
#include <string>
#include <fstream>
#include <cstring>

using std::string;
using std::ifstream;
using std::ofstream;

// Read curve data from file and populate "CurveData"
bool
CurveData::load(const char* filename) {
	return true;
}